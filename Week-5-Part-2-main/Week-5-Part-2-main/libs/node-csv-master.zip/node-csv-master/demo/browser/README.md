
# Native browser

The package illustrates the native integration of the CSV packages in a browser environnment.

## Testing

There are no test for this package. The only way is to start the server and navigate the pages. We could use headless browser tests.
