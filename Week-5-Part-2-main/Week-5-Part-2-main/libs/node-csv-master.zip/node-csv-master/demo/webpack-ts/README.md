
# `webpack` bundler with TypeScript demonstration

The project illustrates the usage of TypeScript with `webpack` version 5.

## Running

```bash
npm run build
npm run start
```

## Testing

```bash
npm run test
```

The test suite consists in building the code with webpack. We don't check if the code is working.
