
# ESM demo

The package illustrates the usage of ESM inside a Node.js environment. It uses JavaScript and TypeScript.

## Testing

The test suite execute each sample present in the `./lib` folder.
