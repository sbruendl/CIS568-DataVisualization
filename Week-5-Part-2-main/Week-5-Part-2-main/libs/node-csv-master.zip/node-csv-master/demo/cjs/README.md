
# Node.js CSV demo for CommonJS

The package illustrates the usage of CommonJS modules inside a Node.js environment. It uses JavaScript and TypeScript.

## Testing

The test suite execute each sample present in the `./lib` folder.

For Node.js 12 and above, run `yarn test`. For versions below 12 and above 8, run `./test/node8.sh`.
