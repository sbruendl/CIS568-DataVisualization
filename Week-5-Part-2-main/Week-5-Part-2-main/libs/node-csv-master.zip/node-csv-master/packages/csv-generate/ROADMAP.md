# Roadmap

* test: ensure every sample is valid
* seed: always a number, value "0" disable the feature
* Promise module API
* record_delimiter: rename from row_delimiter
* internal: store options in snake case form
